package es.uv.codingdojo.gildedrose;

/**
 * @author codingDojo
 *
 */
public class GildedRose {
    public static final String AGED_BRIE = "Aged Brie";
    public static final String BACKSTAGE_PASSES = "Backstage passes to a TAFKAL80ETC concert";
    public static final String SULFURAS_HAND_OF_RAGNAROS = "Sulfuras, Hand of Ragnaros";
    public static int MIN_QUALITY = 0;
    public static int MAX_QUALITY = 50;
    Item[] items;

    public GildedRose(Item[] items) {
        this.items = items;
    }


    public void updateQuality() {

        for (int i = 0; i < this.items.length; i++) {

            Item item = this.items[i];

            updateQuality(item);
            decreaseSellIn(item);
            specialRulesForQualityAfterSellIn(item);
        }
    }

    private static void specialRulesForQualityAfterSellIn(Item item) {
        if (item.getSellIn() < 0) {
            if (isNotAgedBrie(item)) {
                if (isNotBackstagePasses(item)) {
                    decreaseQuality(item);
                } else {
                    item.setQuality(item.getQuality() - item.getQuality());
                }
            } else {
                increaseQuality(item);
            }
        }
    }

    private static void updateQuality(Item item) {
        if (isNotAgedBrie(item) && isNotBackstagePasses(item)) {
            decreaseQuality(item);
        } else {
            increaseQuality(item);
            applySpecialsRulesForBackstagePasses(item);
        }
    }

    private static void applySpecialsRulesForBackstagePasses(Item item) {
        if (item.getName().equals(BACKSTAGE_PASSES)) {
            if (item.getSellIn() < 11) {
                increaseQuality(item);
            }

            if (item.getSellIn() < 6) {
                increaseQuality(item);
            }
        }
    }

    private static void decreaseSellIn(Item item) {
        if (isNotSulfuras(item)) {
            item.setSellIn(item.getSellIn() - 1);
        }
    }

    private static void increaseQuality(Item item) {
        if (item.getQuality() < MAX_QUALITY) {
            item.setQuality(item.getQuality() + 1);
        }
    }

    private static void decreaseQuality(Item item) {
        if (hasQuality(item)) {
            if (isNotSulfuras(item)) {
                item.setQuality(item.getQuality() - 1);
            }
        }
    }

    private static boolean hasQuality(Item item) {
        return item.getQuality() > MIN_QUALITY;
    }

    private static boolean isNotSulfuras(Item item) {
        return !item.getName().equals(SULFURAS_HAND_OF_RAGNAROS);
    }

    private static boolean isNotBackstagePasses(Item item) {
        return !item.getName().equals(BACKSTAGE_PASSES);
    }

    private static boolean isNotAgedBrie(Item item) {
        return !item.getName().equals(AGED_BRIE);
    }
}
